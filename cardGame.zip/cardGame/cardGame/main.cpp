#include "Game.h"
#include "character.h"
int main()
{
    Game game;
    game.start();
    return 0;
}
